--[[ Gold Snap
  Gold gained -> battle-text style popup at your cursor -> coins fly to a draggable counter ->
  the counter's digits roll up over a few seconds. Left-click the counter for stats,
  right-click for options.  Slash: /goldsnap  (or /gsnap)
]]
local ADDON = ...

---------------------------------------------------------------------------
-- Settings / saved data
---------------------------------------------------------------------------
local DEFAULTS = {
    popup = true,        -- floating text at the cursor
    coins = true,        -- coins fly from the popup to the counter
    locked = false,      -- counter position locked
    countOther = true,   -- animate vendor / auction / trade income too
    font = "Friz Quadrata",
    fontSize = 26,       -- counter base size
    popupSize = 30,      -- cursor popup size
    duration = 3,        -- seconds the counter roll runs
    coinStyle = "snap",  -- "snap" = Gold Snap painted coins, "game" = WoW's own coin icons
}

local db, cdb
local SOURCES = { "quest", "loot", "mail", "other" }
local LABELS = { quest = "Quests", loot = "Looted", mail = "Mail", other = "Other (vendor/AH/trade)" }
local session = { quest = 0, loot = 0, mail = 0, other = 0 }
local sessionStart = GetTime()
local pending = 0        -- gold earned whose coins are still in flight
local lastMoney = 0
local debugMode = false
local OpenOptions        -- forward declaration, defined with the options panel

local floor, max, min = math.floor, math.max, math.min
local sin, cos, abs, pi = math.sin, math.cos, math.abs, math.pi

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
local MEDIA = "Interface\\AddOns\\GoldSnap\\Media\\"
local COIN_STYLES = {
    game = {
        gold = "Interface\\MoneyFrame\\UI-GoldIcon",
        silver = "Interface\\MoneyFrame\\UI-SilverIcon",
        copper = "Interface\\MoneyFrame\\UI-CopperIcon",
    },
    snap = {
        gold = MEDIA .. "coin_gold",
        silver = MEDIA .. "coin_silver",
        copper = MEDIA .. "coin_copper",
    },
}
local function CoinTex(kind)
    return (COIN_STYLES[db.coinStyle] or COIN_STYLES.snap)[kind]
end

local BUILTIN_FONTS = {
    ["Friz Quadrata"] = "Fonts\\FRIZQT__.TTF",
    ["Arial Narrow"] = "Fonts\\ARIALN.TTF",
    ["Morpheus"] = "Fonts\\MORPHEUS.TTF",
    ["Skurri"] = "Fonts\\SKURRI.TTF",
}

local function GetLSM()
    return LibStub and LibStub("LibSharedMedia-3.0", true) or nil
end

local function FontList()
    local list = {}
    for name in pairs(BUILTIN_FONTS) do list[#list + 1] = name end
    local LSM = GetLSM()
    if LSM then
        for _, name in ipairs(LSM:List("font")) do
            if not BUILTIN_FONTS[name] then list[#list + 1] = name end
        end
    end
    table.sort(list)
    return list
end

local function FontPath(name)
    if BUILTIN_FONTS[name] then return BUILTIN_FONTS[name] end
    local LSM = GetLSM()
    if LSM then
        local path = LSM:Fetch("font", name, true)
        if path then return path end
    end
    return BUILTIN_FONTS["Friz Quadrata"]
end

local function SetFontSafe(fs, name, size)
    local ok = fs:SetFont(FontPath(name), size, "OUTLINE")
    if ok == false then fs:SetFont(BUILTIN_FONTS["Friz Quadrata"], size, "OUTLINE") end
end

local function Commas(n)
    local s, k = tostring(n), 0
    repeat s, k = s:gsub("^(-?%d+)(%d%d%d)", "%1,%2") until k == 0
    return s
end

local function Icon(kind, size)
    return string.format("|T%s:%d:%d:2:0|t", CoinTex(kind), size, size)
end

-- compact = only show non-zero units (used for the +X popup)
local function FormatMoney(copper, size, compact)
    copper = floor(copper + 0.5)
    size = floor(size or 14)
    local g, s, c = floor(copper / 10000), floor(copper / 100) % 100, copper % 100
    local out = {}
    if compact then
        if g > 0 then out[#out + 1] = Commas(g) .. Icon("gold", size) end
        if s > 0 then out[#out + 1] = s .. Icon("silver", size) end
        if c > 0 or #out == 0 then out[#out + 1] = c .. Icon("copper", size) end
    else
        if g > 0 then out[#out + 1] = Commas(g) .. Icon("gold", size) end
        if g > 0 or s > 0 then out[#out + 1] = s .. Icon("silver", size) end
        out[#out + 1] = c .. Icon("copper", size)
    end
    return table.concat(out, " ")
end

local function CursorPos()
    local x, y = GetCursorPosition()
    local scale = UIParent:GetEffectiveScale()
    return x / scale, y / scale
end

local function Say(msg)
    print("|cffffd100Gold Snap:|r " .. msg)
end

---------------------------------------------------------------------------
-- Tiny effect driver (popups and coins share one OnUpdate)
---------------------------------------------------------------------------
local effects = {}
local driver = CreateFrame("Frame")
driver:Hide()
driver:SetScript("OnUpdate", function(self)
    local now = GetTime()
    for i = #effects, 1, -1 do
        local fn = effects[i]
        if fn then
            local ok, finished = pcall(fn, now)
            -- an effect that errors is dropped so it can never wedge the others
            if (not ok) or finished then table.remove(effects, i) end
        end
    end
    if #effects == 0 then self:Hide() end
end)
local function AddEffect(fn)
    effects[#effects + 1] = fn
    driver:Show()
end

---------------------------------------------------------------------------
-- Counter (the draggable gold display)
---------------------------------------------------------------------------
local Counter = { shown = 0, from = 0, to = 0, anim = false }
local stats -- stats frame, built later

function Counter:Build()
    local cf = CreateFrame("Button", "GoldSnapCounter", UIParent)
    cf:SetSize(60, 24)
    cf:SetFrameStrata("HIGH")
    cf:SetMovable(true)
    cf:SetClampedToScreen(true)
    cf:EnableMouse(true)
    cf:RegisterForDrag("LeftButton")
    cf:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    cf.bg = cf:CreateTexture(nil, "BACKGROUND")
    cf.bg:SetAllPoints()
    cf.bg:SetColorTexture(0, 0, 0, 0)

    self.text = cf:CreateFontString(nil, "OVERLAY")
    self.text:SetPoint("CENTER")
    self.text:SetTextColor(1, 0.82, 0)

    local p = db.pos
    if p then
        cf:SetPoint(p[1], UIParent, p[2], p[3], p[4])
    else
        cf:SetPoint("TOP", UIParent, "TOP", 0, -120)
    end

    cf:SetScript("OnDragStart", function(frame)
        if not db.locked then
            frame.wasDragged = true
            frame:StartMoving()
        end
    end)
    cf:SetScript("OnDragStop", function(frame)
        frame:StopMovingOrSizing()
        Counter:SaveAnchor()
    end)
    cf:SetScript("OnClick", function(frame, button)
        if frame.wasDragged then frame.wasDragged = false return end
        if button == "RightButton" then
            OpenOptions()
        elseif stats then
            stats:SetShown(not stats:IsShown())
        end
    end)
    cf:SetScript("OnEnter", function(frame)
        GameTooltip:SetOwner(frame, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Gold Snap", 1, 0.82, 0)
        GameTooltip:AddLine("Left-click: gold stats", 1, 1, 1)
        GameTooltip:AddLine("Right-click: options", 1, 1, 1)
        GameTooltip:AddLine(db.locked and "Locked" or "Drag to move, drag the corner to resize", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    cf:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- resize corner (only visible while unlocked): drag to scale the text up or down
    local grip = CreateFrame("Button", nil, cf)
    grip:SetSize(16, 16)
    grip:SetPoint("BOTTOMRIGHT", cf, "BOTTOMRIGHT", 0, 0)
    grip:SetFrameLevel(cf:GetFrameLevel() + 5)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:SetScript("OnMouseDown", function(g, button)
        if button ~= "LeftButton" or db.locked then return end
        -- pin the top-left corner so the bottom-right corner follows the cursor
        local left, top = cf:GetLeft(), cf:GetTop()
        cf:ClearAllPoints()
        cf:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
        local cx, cy = CursorPos()
        local w, h = cf:GetSize()
        local span = max(60, w + h)
        local startSize = db.fontSize
        g:SetScript("OnUpdate", function()
            local nx, ny = CursorPos()
            local factor = 1 + ((nx - cx) - (ny - cy)) / span
            db.fontSize = floor(max(8, min(200, startSize * factor)) + 0.5)
            Counter:Apply()
        end)
    end)
    grip:SetScript("OnMouseUp", function(g)
        g:SetScript("OnUpdate", nil)
        Counter:SaveAnchor()
    end)
    self.grip = grip

    self.frame = cf
    self:Apply()
end

-- remember the position, anchored to whichever side of the screen the counter is nearest,
-- so it grows away from the edge instead of off the screen
function Counter:SaveAnchor()
    local cf = self.frame
    local l, r, t = cf:GetLeft(), cf:GetRight(), cf:GetTop()
    if not l then return end
    local point, x
    if (l + r) / 2 > UIParent:GetWidth() / 2 then point, x = "TOPRIGHT", r else point, x = "TOPLEFT", l end
    cf:ClearAllPoints()
    cf:SetPoint(point, UIParent, "BOTTOMLEFT", x, t)
    db.pos = { point, "BOTTOMLEFT", x, t }
end

-- size the clickable frame to the text exactly: no padding, so it can sit right at a screen edge
function Counter:Fit()
    local w, h = self.text:GetStringWidth(), self.text:GetStringHeight()
    self.frame:SetSize(max(24, w), max(14, h))
end

function Counter:ApplyFont(size)
    SetFontSafe(self.text, db.font, size or db.fontSize)
end

function Counter:Render(size, noFit)
    self.text:SetText(FormatMoney(self.shown, size or db.fontSize))
    if not noFit then self:Fit() end
end

function Counter:Apply()
    self.frame.bg:SetColorTexture(0, 0, 0, 0)
    self.grip:SetShown(not db.locked)
    if not self.anim then
        self:ApplyFont()
        self:Render()
    end
end

function Counter:Set(value)
    value = max(0, value)
    self.shown, self.from, self.to = value, value, value
    self.anim = false
    self.frame:SetScript("OnUpdate", nil)
    self:ApplyFont()
    self:Render()
end

function Counter:Tick()
    local t = (GetTime() - self.start) / max(0.5, db.duration)
    local size
    if t >= 1 then
        self.shown, self.anim = self.to, false
        self.frame:SetScript("OnUpdate", nil)
        size = db.fontSize
    else
        -- smoothstep: gentle start and finish, steady roll through the middle,
        -- so you can actually watch the digits climb for the whole duration
        local e = t * t * (3 - 2 * t)
        self.shown = self.from + (self.to - self.from) * e
        -- font swells quickly, holds, then eases back down at the end
        local env = (t < 0.12) and (t / 0.12) or ((t > 0.8) and ((1 - t) / 0.2) or 1)
        size = db.fontSize * (1 + 0.6 * env)
    end
    self:ApplyFont(size)
    self:Render(size, t < 1)   -- don't re-fit the frame while the text is swelling
end

function Counter:Add(amount)
    self.from = self.shown
    self.to = self.to + amount
    self.start = GetTime()
    self.anim = true
    self.frame:SetScript("OnUpdate", function() Counter:Tick() end)
end

---------------------------------------------------------------------------
-- Floating popup + flying coins
---------------------------------------------------------------------------
local popupPool, coinPool = {}, {}
local coinLayer = CreateFrame("Frame", nil, UIParent)
coinLayer:SetFrameStrata("TOOLTIP")
coinLayer:SetSize(1, 1)
coinLayer:SetPoint("CENTER")

local function GetPopup()
    local p = table.remove(popupPool)
    if not p then
        p = CreateFrame("Frame", nil, UIParent)
        p:SetFrameStrata("TOOLTIP")
        p:SetSize(1, 1)
        p.text = p:CreateFontString(nil, "OVERLAY")
        p.text:SetPoint("CENTER")
        p.text:SetTextColor(1, 0.82, 0)
    end
    return p
end

local function GetCoin()
    local c = table.remove(coinPool)
    if not c then
        c = coinLayer:CreateTexture(nil, "OVERLAY")
    end
    return c
end

local COIN_SIZE = 26

local function SpawnCoins(amount, sx, sy, onFirstArrive)
    local n = min(10, max(2, floor(math.log10(amount + 1)) + 1))
    local kind = (amount >= 10000 and "gold") or (amount >= 100 and "silver") or "copper"
    local state = { landed = false }
    local t0 = GetTime()
    for i = 1, n do
        local coin = GetCoin()
        coin:SetTexture(CoinTex(kind))
        coin:SetSize(COIN_SIZE, COIN_SIZE)
        coin:Hide()
        local x0 = sx + (math.random() - 0.5) * 40
        local y0 = sy + (math.random() - 0.5) * 20
        local delay, dur = (i - 1) * 0.07, 0.7
        local spin = math.random() * pi
        AddEffect(function(now)
            local t = (now - t0 - delay) / dur
            if t < 0 then return false end
            local cx, cy = Counter.frame:GetCenter()
            if t >= 1 or not cx then
                coin:Hide()
                table.insert(coinPool, coin)
                if not state.landed then
                    state.landed = true
                    onFirstArrive()
                end
                return true
            end
            local e = t * t -- ease-in: accelerates toward the counter
            coin:ClearAllPoints()
            coin:SetPoint("CENTER", UIParent, "BOTTOMLEFT",
                x0 + (cx - x0) * e,
                y0 + (cy - y0) * e + sin(pi * t) * 50)
            -- squash the width to fake the coin spinning in flight
            coin:SetSize(max(4, COIN_SIZE * abs(cos(spin + t * pi * 2.5))), COIN_SIZE)
            coin:Show()
            return false
        end)
    end
end

local function SpawnPopup(amount, x, y, onArrive)
    local p = GetPopup()
    SetFontSafe(p.text, db.font, db.popupSize)
    p.text:SetText("+" .. FormatMoney(amount, db.popupSize, true))
    p:SetAlpha(1)
    p:Show()
    local start, launched = GetTime(), false
    AddEffect(function(now)
        local t = now - start
        local rise = 50 * min(1, t / 0.6)
        p:ClearAllPoints()
        p:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x, y + rise)
        if t >= 0.5 and not launched then
            launched = true
            if db.coins then
                SpawnCoins(amount, x, y + rise, onArrive)
            else
                onArrive()
            end
        end
        if t > 0.5 then p:SetAlpha(max(0, 1 - (t - 0.5) / 0.35)) end
        if t >= 0.9 then
            p:Hide()
            table.insert(popupPool, p)
            return true
        end
        return false
    end)
end

---------------------------------------------------------------------------
-- Gold gained
---------------------------------------------------------------------------
local function Gained(amount, src, x, y, fake)
    if not fake then
        session[src] = session[src] + amount
        cdb.total[src] = (cdb.total[src] or 0) + amount
    end
    if src == "other" and not db.countOther then
        -- vendor/AH/trade with the animation switched off: just keep the counter right
        Counter:Set(Counter.to + amount)
        return
    end
    pending = pending + amount
    local done = false
    local function arrive()
        if done then return end
        done = true
        pending = max(0, pending - amount)
        Counter:Add(amount)
    end
    if db.popup and x then
        SpawnPopup(amount, x, y, arrive)
        -- safety net: whatever happens to the popup, the counter still gets its roll
        C_Timer.After(3, arrive)
    else
        arrive()
    end
end

---------------------------------------------------------------------------
-- Batching: looting several corpses at once shows ONE combined total
---------------------------------------------------------------------------
local batch = { amounts = {} }
local batchSeq = 0
local BATCH_WAIT, BATCH_MAX = 0.35, 1.0

local function FlushBatch()
    local b = batch
    batch = { amounts = {} }
    for _, src in ipairs(SOURCES) do
        local amount = b.amounts[src]
        if amount and amount > 0 then
            if debugMode then Say(string.format("%s gained: %d copper", src, amount)) end
            Gained(amount, src, b.x, b.y, b.fake)
        end
    end
end

local function QueueGain(amount, src, x, y, fake)
    if not batch.first then
        batch.first, batch.x, batch.y = GetTime(), x, y
    end
    if fake then batch.fake = true end
    batch.amounts[src] = (batch.amounts[src] or 0) + amount
    batchSeq = batchSeq + 1
    local mySeq = batchSeq
    local wait = min(BATCH_WAIT, max(0.05, BATCH_MAX - (GetTime() - batch.first)))
    C_Timer.After(wait, function()
        if mySeq == batchSeq then FlushBatch() end
    end)
end

---------------------------------------------------------------------------
-- Source detection (only used for the stats breakdown)
---------------------------------------------------------------------------
local flags = {}
local lastClick = { t = -10 }

local function Flag(src) flags[src] = GetTime() end
local function MarkClick()
    local x, y = CursorPos()
    lastClick.x, lastClick.y, lastClick.t = x, y, GetTime()
end

local function Classify()
    local now, best, bestT = GetTime(), "other", -1
    for _, src in ipairs({ "quest", "mail", "loot" }) do
        local t = flags[src]
        if t and now - t < 3 and t > bestT then best, bestT = src, t end
    end
    return best
end

local function SafeHook(tbl, name, fn)
    if tbl and type(tbl[name]) == "function" then
        pcall(hooksecurefunc, tbl, name, fn)
    end
end

local function OnMoney()
    local cur = GetMoney()
    local delta = cur - lastMoney
    lastMoney = cur
    if delta < 0 then
        Counter:Set(cur - pending)   -- spent gold: snap the counter down
        return
    end
    if delta == 0 then return end
    local x, y
    if lastClick.x and GetTime() - lastClick.t < 1.5 then
        x, y = lastClick.x, lastClick.y
    else
        x, y = CursorPos()
    end
    -- give the loot / quest / mail events a moment to arrive so we can label the source
    C_Timer.After(0.1, function() QueueGain(delta, Classify(), x, y) end)
end

---------------------------------------------------------------------------
-- Stats window
---------------------------------------------------------------------------
local function BuildStats()
    local s = CreateFrame("Frame", "GoldSnapStats", UIParent)
    s:SetSize(440, 250)
    s:SetFrameStrata("DIALOG")
    s:SetClampedToScreen(true)
    s:SetMovable(true)
    s:EnableMouse(true)
    s:RegisterForDrag("LeftButton")
    s:SetScript("OnDragStart", s.StartMoving)
    s:SetScript("OnDragStop", s.StopMovingOrSizing)
    s:SetPoint("TOP", Counter.frame, "BOTTOM", 0, -8)
    s:Hide()

    local bg = s:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.85)

    local title = s:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 14, -12)
    title:SetText("Gold Snap - Stats")

    local close = CreateFrame("Button", nil, s, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", 0, 0)

    local function Label(text, x, y, template)
        local fs = s:CreateFontString(nil, "OVERLAY", template or "GameFontNormalSmall")
        fs:SetPoint("TOPLEFT", x, y)
        fs:SetText(text)
        return fs
    end
    local function Value(x, y, width)
        local fs = s:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetPoint("TOPLEFT", x, y)
        fs:SetWidth(width or 190)
        fs:SetJustifyH("LEFT")
        return fs
    end

    Label("Session time", 14, -42)
    s.time = Value(240, -42)
    Label("Gold per hour", 14, -62)
    s.gph = Value(240, -62)
    Label("Gold this session", 14, -82)
    s.sessionTotal = Value(240, -82)
    Label("Gold earned on this character (all time)", 14, -102)
    s.allTotal = Value(240, -102)

    Label("Sources", 14, -134, "GameFontNormal")
    Label("This session", 130, -134)
    Label("All time", 285, -134)
    s.rows = {}
    for i, src in ipairs(SOURCES) do
        local y = -154 - (i - 1) * 20
        Label(LABELS[src], 14, y)
        s.rows[src] = { Value(130, y, 150), Value(285, y, 150) }
    end

    local reset = CreateFrame("Button", nil, s, "UIPanelButtonTemplate")
    reset:SetSize(120, 22)
    reset:SetPoint("BOTTOMRIGHT", -12, 10)
    reset:SetText("Reset session")
    reset:SetScript("OnClick", function()
        for _, src in ipairs(SOURCES) do session[src] = 0 end
        sessionStart = GetTime()
        s:Refresh()
    end)

    function s:Refresh()
        local elapsed = GetTime() - sessionStart
        local sTotal, aTotal = 0, 0
        for _, src in ipairs(SOURCES) do
            sTotal = sTotal + session[src]
            aTotal = aTotal + (cdb.total[src] or 0)
            self.rows[src][1]:SetText(FormatMoney(session[src], 12, true))
            self.rows[src][2]:SetText(FormatMoney(cdb.total[src] or 0, 12, true))
        end
        self.time:SetText(string.format("%dh %02dm %02ds",
            floor(elapsed / 3600), floor(elapsed / 60) % 60, floor(elapsed) % 60))
        if elapsed >= 30 then
            self.gph:SetText(FormatMoney(sTotal / (elapsed / 3600), 12, true))
        else
            self.gph:SetText("calculating...")
        end
        self.sessionTotal:SetText(FormatMoney(sTotal, 12, true))
        self.allTotal:SetText(FormatMoney(aTotal, 12, true))
    end

    local acc = 0
    s:SetScript("OnUpdate", function(self, elapsed)
        acc = acc + elapsed
        if acc >= 0.5 then acc = 0 self:Refresh() end
    end)
    s:SetScript("OnShow", function(self) self:Refresh() end)
    stats = s
end

---------------------------------------------------------------------------
-- Tests
---------------------------------------------------------------------------
local function RestoreCounterSoon()
    -- test gold isn't real, so put the counter back to the true total afterwards
    C_Timer.After(db.duration + 2.5, function() Counter:Set(GetMoney() - pending) end)
end

local function TestDrop()
    local x, y = CursorPos()
    QueueGain(math.random(500, 250000), "loot", x, y, true)
    RestoreCounterSoon()
end

local function TestGroup()
    -- three "corpses" in quick succession: should merge into one combined popup
    local x, y = CursorPos()
    for i = 1, 3 do
        C_Timer.After((i - 1) * 0.15, function()
            QueueGain(math.random(500, 90000), "loot", x, y, true)
        end)
    end
    RestoreCounterSoon()
end

---------------------------------------------------------------------------
-- Options panel
---------------------------------------------------------------------------
local optionsPanel, optionsCategory

function OpenOptions()
    if Settings and Settings.OpenToCategory and optionsCategory then
        Settings.OpenToCategory(optionsCategory:GetID())
    elseif InterfaceOptionsFrame_OpenToCategory and optionsPanel then
        InterfaceOptionsFrame_OpenToCategory(optionsPanel)
        InterfaceOptionsFrame_OpenToCategory(optionsPanel) -- first call often misses
    end
end

local function BuildOptions()
    local panel = CreateFrame("Frame", "GoldSnapOptions")
    panel.name = "Gold Snap"
    local refreshers = {}
    local y = -50

    local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("Gold Snap")

    local function Check(label, key)
        local cb = CreateFrame("CheckButton", nil, panel)
        cb:SetSize(26, 26)
        cb:SetPoint("TOPLEFT", 12, y)
        cb:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
        cb:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down")
        cb:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight", "ADD")
        cb:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
        local fs = cb:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        fs:SetPoint("LEFT", cb, "RIGHT", 4, 0)
        fs:SetText(label)
        cb:SetScript("OnClick", function(self)
            db[key] = self:GetChecked() and true or false
            Counter:Apply()
        end)
        refreshers[#refreshers + 1] = function() cb:SetChecked(db[key]) end
        y = y - 28
    end

    local function Slider(label, key, lo, hi, step)
        local fs = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        fs:SetPoint("TOPLEFT", 16, y)
        local s = CreateFrame("Slider", nil, panel)
        s:SetOrientation("HORIZONTAL")
        s:SetSize(240, 16)
        s:SetPoint("TOPLEFT", 20, y - 22)
        s:SetMinMaxValues(lo, hi)
        s:SetValueStep(step)
        if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
        local bar = s:CreateTexture(nil, "BACKGROUND")
        bar:SetColorTexture(0.3, 0.3, 0.3, 1)
        bar:SetHeight(4)
        bar:SetPoint("LEFT")
        bar:SetPoint("RIGHT")
        s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
        local thumb = s:GetThumbTexture()
        if thumb then thumb:SetSize(24, 24) end
        local function Text() fs:SetText(label .. ": " .. tostring(db[key])) end
        s:SetScript("OnValueChanged", function(_, v)
            db[key] = floor(v / step + 0.5) * step
            Text()
            Counter:Apply()
        end)
        refreshers[#refreshers + 1] = function() s:SetValue(db[key]) Text() end
        y = y - 50
    end

    Check("Floating gold text at the cursor", "popup")
    Check("Coins fly to the counter", "coins")
    Check("Lock counter (hides the resize corner)", "locked")
    Check("Also animate vendor / auction / trade income", "countOther")
    y = y - 10
    Slider("Counter font size", "fontSize", 8, 150, 1)
    Slider("Cursor popup font size", "popupSize", 12, 60, 1)
    Slider("Counter roll length (seconds)", "duration", 1, 6, 0.5)

    -- font picker: click to cycle forward, right-click to go back
    local fontBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    fontBtn:SetSize(260, 24)
    fontBtn:SetPoint("TOPLEFT", 16, y)
    fontBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    local function FontText() fontBtn:SetText("Font: " .. db.font .. "  (click to change)") end
    fontBtn:SetScript("OnClick", function(_, button)
        local list = FontList()
        local idx = 1
        for i, name in ipairs(list) do if name == db.font then idx = i end end
        idx = idx + (button == "RightButton" and -1 or 1)
        if idx < 1 then idx = #list elseif idx > #list then idx = 1 end
        db.font = list[idx]
        FontText()
        Counter:Apply()
    end)
    refreshers[#refreshers + 1] = FontText
    y = y - 34

    -- coin icon style: the game's own icons, or the smoother custom ones
    local coinBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    coinBtn:SetSize(260, 24)
    coinBtn:SetPoint("TOPLEFT", 16, y)
    local function CoinText()
        coinBtn:SetText("Coin icons: " .. (db.coinStyle == "game" and "WoW default" or "Gold Snap painted"))
    end
    coinBtn:SetScript("OnClick", function()
        db.coinStyle = (db.coinStyle == "game") and "snap" or "game"
        CoinText()
        Counter:Apply()
    end)
    refreshers[#refreshers + 1] = CoinText
    y = y - 40

    local function Button(text, width, x, onClick)
        local b = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
        b:SetSize(width, 24)
        b:SetPoint("TOPLEFT", x, y)
        b:SetText(text)
        b:SetScript("OnClick", onClick)
    end
    Button("Test drop", 90, 16, TestDrop)
    Button("Test group loot", 115, 114, TestGroup)
    Button("Reset position", 110, 237, function()
        db.pos = nil
        Counter.frame:ClearAllPoints()
        Counter.frame:SetPoint("TOP", UIParent, "TOP", 0, -120)
    end)
    Button("Open stats", 90, 355, function() stats:Show() end)

    local function Refresh() for _, fn in ipairs(refreshers) do fn() end end
    panel:SetScript("OnShow", Refresh)
    -- harmless stubs so both the new Settings API and the old InterfaceOptions API are happy
    panel.OnCommit, panel.OnDefault, panel.OnRefresh = function() end, function() end, Refresh
    panel.okay, panel.cancel, panel.default, panel.refresh = function() end, function() end, function() end, Refresh

    if Settings and Settings.RegisterCanvasLayoutCategory then
        optionsCategory = Settings.RegisterCanvasLayoutCategory(panel, panel.name)
        Settings.RegisterAddOnCategory(optionsCategory)
    elseif InterfaceOptions_AddCategory then
        InterfaceOptions_AddCategory(panel)
    end
    optionsPanel = panel
end

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------
SLASH_GOLDSNAP1 = "/goldsnap"
SLASH_GOLDSNAP2 = "/gsnap"
SlashCmdList["GOLDSNAP"] = function(msg)
    msg = strlower(strtrim(msg or ""))
    if msg == "test" then
        TestDrop()
    elseif msg == "group" then
        TestGroup()
    elseif msg == "stats" then
        stats:SetShown(not stats:IsShown())
    elseif msg == "lock" or msg == "unlock" then
        db.locked = (msg == "lock")
        Counter:Apply()
        Say("counter " .. (db.locked and "locked" or "unlocked"))
    elseif msg == "debug" then
        debugMode = not debugMode
        Say("debug " .. (debugMode and "on" or "off"))
    else
        Say("/gsnap  (options)  |  test  |  group  |  stats  |  lock  |  unlock  |  debug")
        OpenOptions()
    end
end

---------------------------------------------------------------------------
-- Boot
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        if (...) ~= ADDON then return end
        GoldSnapDB = GoldSnapDB or {}
        for k, v in pairs(DEFAULTS) do
            if GoldSnapDB[k] == nil then GoldSnapDB[k] = v end
        end
        GoldSnapCharDB = GoldSnapCharDB or {}
        GoldSnapCharDB.total = GoldSnapCharDB.total or {}
        for _, src in ipairs(SOURCES) do
            GoldSnapCharDB.total[src] = GoldSnapCharDB.total[src] or 0
        end
        db, cdb = GoldSnapDB, GoldSnapCharDB
        if not db.v4 then db.v4 = true db.coinStyle = "snap" end  -- switch existing installs to the new coins
        self:UnregisterEvent("ADDON_LOADED")

    elseif event == "PLAYER_LOGIN" then
        sessionStart = GetTime()
        lastMoney = GetMoney()
        Counter:Build()
        Counter:Set(lastMoney)
        BuildStats()
        BuildOptions()

        -- remember where you clicked (loot windows, quest turn-ins, mailbox)
        local function LootHook() MarkClick() Flag("loot") end
        SafeHook(_G, "LootSlot", LootHook)
        SafeHook(_G, "GetQuestReward", MarkClick)
        SafeHook(C_QuestOffer, "GetQuestReward", MarkClick)
        local function MailHook() MarkClick() Flag("mail") end
        SafeHook(_G, "TakeInboxMoney", MailHook)
        SafeHook(C_Mail, "TakeInboxMoney", MailHook)
        SafeHook(_G, "AutoLootMailItem", MailHook)
        SafeHook(C_Mail, "AutoLootMailItem", MailHook)

        for _, name in ipairs({ "PLAYER_MONEY", "CHAT_MSG_MONEY", "QUEST_TURNED_IN",
                                "LOOT_READY", "LOOT_OPENED", "LOOT_CLOSED" }) do
            pcall(self.RegisterEvent, self, name)  -- skip any event this client doesn't have
        end

    elseif event == "PLAYER_MONEY" then
        OnMoney()
    elseif event == "CHAT_MSG_MONEY" or event == "LOOT_READY" or event == "LOOT_OPENED"
        or event == "LOOT_CLOSED" then
        Flag("loot")
    elseif event == "QUEST_TURNED_IN" then
        local _, _, money = ...
        if money and money > 0 then Flag("quest") end
    end
end)
