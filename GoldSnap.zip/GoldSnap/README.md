# Gold Snap

Make every bit of gold feel good. When you gain gold, the amount pops up like battle text at your cursor, coins fly across the screen to a gold counter, and the digits roll up to your new total.

## Features
- **Cursor popup:** gold from corpses, quest rewards and mail appears where you clicked. Looting several corpses at once shows one combined total.
- **Flying coins:** painted gold, silver and copper coins travel from the popup to your counter.
- **Rolling counter:** the digits count up over a few seconds while the text swells and settles.
- **Move and resize:** drag the counter anywhere. While unlocked, drag the bottom-right corner to make it as big or small as you like. There is no padding around the text, so it can sit right against a screen edge.
- **Gold stats:** click the counter to see gold per hour, gold this session, all-time gold on this character, and a breakdown by source (quests, looted, mail, other).
- **Options:** change the font (built-in fonts plus any LibSharedMedia fonts), popup and counter sizes, roll length, and coin icon style.

## Controls
- Left-click the counter: stats
- Right-click the counter: options
- Drag the counter: move it (when unlocked)
- Drag the corner grip: resize (when unlocked)

## Slash commands
`/gsnap` or `/goldsnap`
- `/gsnap` opens options
- `/gsnap stats` toggles the stats window
- `/gsnap lock` and `/gsnap unlock`
- `/gsnap test` plays a test drop, `/gsnap group` plays a test group loot
- `/gsnap debug` prints what the addon thinks each gain was (useful for bug reports)

## Installing
Unzip the `GoldSnap` folder into your `Interface/AddOns` folder for your game version, then restart the game.

## Notes
- All-time stats count from the day you install the addon.
- Session stats reset when you reload the UI.
- The coin artwork was generated with AI image tools.

## License
MIT. See LICENSE.
