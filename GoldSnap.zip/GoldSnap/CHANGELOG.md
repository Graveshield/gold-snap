# Changelog

## 1.0.0
- First public release.
- Floating gold text at your cursor when you gain gold, merged into one combined total when you loot several corpses at once.
- Painted gold, silver and copper coins fly from the popup to your counter.
- Draggable counter with rolling digits over a configurable length (default 3 seconds) and a swelling font.
- Resize the counter by dragging its corner while unlocked. The counter has no padding, so it can sit right at a screen edge.
- Click the counter for stats: gold per hour, gold this session, all-time gold on this character, and a breakdown by source (quests, looted, mail, other).
- Options: font (built-in fonts plus any LibSharedMedia fonts), font sizes, roll length, coin icon style (Gold Snap painted or WoW default), lock position.
- Slash commands: /gsnap, /goldsnap.
